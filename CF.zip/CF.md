# CF

exercise—整理加密货币—复习资料题目—往年试卷题目—其他加密货币—整理一遍计算题—anki

违法相关

Pseudonymous

resistance to censorship

Fraud

**Plagiarism **

money laundering

corruption

Evade tax&#x20;

数据相关

账户相关

auditing, accounting审计，会计

naminal&#x20;

fraud

plagiarism

pseudonymous

auditing accounting



总结：快，安全，透明，减少cost, 腐败，不容易坏,** peer to peer，stop double-spending， 51 attack,Permissionless**

# CF简答题

## Computational Finance

#### Cryptocurrency

*   What is Distributed Ledger Technology?

    *   tips&#x20;

        *   Start with what is a ledger

        *   DLT – distributed network

        *   Advantages - Affordances

        *   Examples of use

        *   ledger : record contracts and transaction for buying and selling , or assert exchange.

            *   using decentralized network to form a trust system that is based on cryptography and technology no person or centralized authorities. and change made to transparent

            *   **any changes made to the ledger are reletrd**

            *   advantage : improve transparency and security and reduce overhead cost.

                *   tamperproof&#x20;

                *   easy to access

                *   distributed: the system still work when on point failur，synchronised across the all nodes in the network.

    *   my

        improve transparency and security and reduce corruption and redecing the overhead caost of auditing and account . tamperproof , no one point failure because distributed

        do't ned to trust each  every one have easily to aeecss&#x20;

*   Briefly describe what is a blockchain?

    *   tips

        **A series of encrypted blocks and given a hash value.**

        *   Explain how it is built on top of the internet

            *   each blockchain have a 64 bit hashvalue and it depends on previous block's hash value.

                *   信任来自于technology and cryptography

                *   between people who may not otherwise trust each other 不信任

                *   secure, trusted records 记录

                *   on a peer-to-peer distributed network 分布 and every note have a whole copy of blockchain

        *   A peer to peer trusted network

            *   secure, trusted record/

            *   people not wish to trust each other 

            *   trust based on cryptography

            *   **every one have whole copy of blockchain**

    *   it is a encrypted block with hash value

*   How can cryptocurrency support digital cash? creation&#x20;

    *   tips 2 2.3

        *   Explain the rationale for the concept of digital cash

            *   all type monetary assert in digital form and needs a payment network with accounts

        *   The need for cryptography 3

            *   **stop double-spending**

            *   keep the transactions **secure** and authentic.

            *   manage and **control** the creation of new currency units.

    *   my ans:

        the monetary currency in digital form.&#x20;

        cryptocurrency can make transaction security and transparent, it also control and manage the creation of new digital cash

*

*   What are the main features of a cryptocurrency?  dlt,blockchain,cryptography

    *   tips

        *   Describe what is meant by cryptocurrencies 2

            存在并通过分布式账本进行交易，通常在专用的基于区块链的网络上，该网络用作公共金融交易数据库

            *   Use cryptography technology to

                *   keep the transactions **secure** and authentic.

                *   manage and **control** the creation of new currency units.

        *   Give properties, especially the transaction properties

            *   tips

                *   Irreversible：经过确认后，交易是不可逆的

                *   \*   Pseudonymous：你可以分析交易流程，但是很难将用户的真实身份与这些地址联系起来。

                *   Fast and global：与**距离无关**，交易在网络中几乎**立即传播**，并在**几分钟内得到确认**。

                *   Secure：只有**私钥**的所有者才能发送加密货币

                *   **Permissionless**（不需要许可）：一旦安装，你可以收发加密货币。

                *   Monetary Properties of Cryptocurrency

                    *   Controlled supply

                        *   大多数加密货币限制了代币的供应。

                        *   所有加密货币都通过用代码编写的时间表来控制令牌的供应。

                    *   No debt but bearer

                        *   法定货币是一种借条体系。

                        *   加密货币只是代表它们自己。

    *   my ans:

        Exist and transaction by digital ledger typically on blockchain network  which is used to form a public finance transaction databse. and use cryptography technolo to kepp transaction security and authentic and managed and control the generation of new currency units.



        irreversible secure pseudonymous fast and global , permissonless&#x20;

*   What are the concerns over cryptocurrency?

    *   tips

        *   Explain the central bank’s concern

            无法被控制—控制通胀

            削弱了中央银行控制货币政策的能力，不受政治影响。

        *   Concern over criminal actions

            *   can be used as tool for **anonymous criminal activity**. such as black market 交易,Evade tax和 money laundering

    *   it reduce the effect from the central bank and bank will hard to control  inflation by print or restrict currency

    *   it can be used for crime. for example criminal can use cyc to money laundering and uset to&#x20;

    transaction system is independence from formal bank system, to central bank hard to contral monetary policy

    the supply of cryptocurrency is controlled which will lead to central bank cannot control inflation by printing or restrick money

    It can be used to some crime action. for examply, it's is&#x20;

    Evade tax and money laundering

*   **What benefits does “Distributed Ledger Technology” provide when developing a digital currency**&#x20;

    *   real ans

        DLT 提供了一个分散的点对点网络，所以没有单点故障

        •建立互不信任的可信赖系统

        •基于密码，而不是人或中央权威

        **使用密钥和加密签名进行访问**

        **任何更改都会反映并抄送给所有参与者**

        •每个参与者都拥有一份相同的副本

        **•提供信息历史记录的完整审计线索**

        **•用于记录、跟踪、监控和交易**

        •透明度、减少腐败(防篡改)和安全性，同时减少审计、会计的间接成本

        Secure, trusted records (of value and exchange) of transactions
        • DLT provide a decentralized peer-to-peer network, so no single point of failure
        • Forming a trusted system b/w who not trust each other
        • Based on crypto, not people or a centralized authority
        • Accessed using keys and cryptographic signatures
        • Any changes are **reflected** and copied to all participants
        • Each participant owns an identical copy
        • Provide a full audit trail of information history
        • For the recording, tracking, monitoring, and transacting
        • Transparency, reduce corruption (tamperproof) and security while reducing&#x20;
        overhead cost of auditing, accounting

    *

p to p&#x20;

secure tranpac&#x20;

base on&#x20;

not turst

trace

record&#x20;

cpy

key















p to p on fali

tranpancy

secure

tampaerproof

key

trace

copy&#x20;

change

### Token economies

*   Explain the concept behind Coloured Coins

    *   real ans

        When coloured coins are created, the relevant piece of code is inserted in a bitcoin transaction

        *   Can serve as a certificate of ownership of any kind of asset commodity or property on the Bitcoin blockchain and creates an asset ID with timestamp

        *   When transacted on the Bitcoin blockchain this effectively transfers the value and ownership of the external assets associated with the coloured coins

        当创建彩色硬币时，相关的代码被插入到比特币交易中

        ‧ 可以作为比特币区块链上任何一种资产商品或财产的所有权证明，并创建带有时间戳的资产ID

        ‧ 当在比特币区块链上进行交易时，这有效地转移了与彩色硬币相关的外部资产的**价值和所有权**

        it only need extremely  small amount of bitcoin

    *   my ans

        when the color coins are generated , a relevant piece of code is inserted to bitcoin transaction. It can be ownership of digital or physial assert, and also can be a license to a assert for special purpose&#x20;

    *   and create **a assert ID with timestamp**

    *   when transacted on the bitcoin network , it can efficiently transfer the value and ownership of external assert associated with color coin

    *   it only need extremely  small amount of bitcoin

*   **Using examples explain what are “coloured coins”?** 8 **钱包** **比特币**

    •一段元数据(插入了一段代码)

    *   **确定这些属于某一特定群体**

    **•任何种类资产的所有权证明书**

    **转移价值和所有权**

    •**极少量的比特币面值**

    **•特别钱包**

    •餐厅奖励制度

    •彩色硬币可兑换一定数量的黄金

    • A piece of metadata (piece of code is inserted)
    • Identifying these as belonging to a particular group
    • A certificate of ownership of any kind of asset
    • Transfers the value and ownership
    • An extremely small amount of nominal bitcoin value
    • Special wallet
    • A reward system for a restaurant
    • Colour coins are redeemable for a certain amount of gold   redeemable

*   What are tokens? **Give some examples of how digital tokens are used**

    *   real ans: 2

        A token is simply a quantified unit of value. It define any form of value and exchangeable between different specific forms of value. They are digital and programmable. Asset-backed tokens are the digital equivalent.

        令牌只是一个量化的价值单位。它定义了任何形式的价值，并可在不同的具体价值形式之间进行交换。它们是数字化的和可编程的。资产支持的令牌相当于数字令牌。

        token is simply a quantified unit of vale. it define any form of value and exchangeable between different special form of value . for example , if i have&#x20;

        例⼦1你开了一家餐馆，每个人每付一顿饭就会得到一枚彩币，10枚彩币相当于一顿免费的饭

        例⼦2你有一个金库，你可以给彩币兑换一定数量的金子。

    *   my ans:

        token is a quantitied unit of value





*   Explain what a Dapp is, Pros and Cons,** examples**

    *   true ans

        *   DAPP-decentralized APP,A Dapp has its **backend code** running on a **decentralized peer-to-peer **network

        *   DAPP-去中心化应用程序，DAPP的后端代码在去中心化的对等网络上运行

        *   不一定重要

            令牌是 Dapp 的当地货币，可以通过三种方式获得:

            1.  通过参与首次发行“ ico”，80% 被出售，20% 留给开发者和创始人

            2.  Dapp 上的用户，提供他们的服务来交换令牌

            3.  在二手市场购买

        Benefits: zero downtime, privacy, r**esistance to censorship**, and complete data integrity

        *   优点: 零停机时间、隐私、抵抗审查和完整的数据。  4



        Drawbacks: harder **maintenance**, performance overhead, and user experience&#x20;

        *   缺点: 更难维护、性能开销和用户体验  3





        *   examples

            1\)Storj is a decentralized DropBox, Token is called the “Storjcoin” • Platform takes payment, sends files to suppliers for encrypting and storing• Suppliers are paid in Storjcoin

            Storj 是一个去中心化的 DropBox，Token 被称为“Storjcoin” • 平台收款，将文件发送给供应商进行加密和存储 • 供应商以 Storjcoin 支付

            2\)Golem is a decentralized form of Amazon Web Services, Token is “Golem” • System sends calculation to supplier and are paid in Golem on completion of the calculation

            Golem 是 Amazon Web Services 的去中心化形式，代币是“Golem”• 系统将计算发送给供应商，并在计算完成后以 Golem 支付

            3\)Augur is a decentralized Bookmaker, Token is “REP” • Bets are placed, the community votes on the outcome, Correct bets win

            Augur 是一个去中心化的博彩公司，代币是“REP”• 投注，社区投票结果，正确投注获胜

    *   my ans

        it has backend code running on d ptp nt

        good privacy and secure and resistance to censorship and zero downtime

        bed hard to maintenance and user experience and perfremance overhead

*   Explain what a DAO is. Contrast to a traditional organization

    *   real ans:

        Decentralized Autonomous Organization

        分散的自治组织

        ![](image/image_QUcaKPH7mt.png)

        | DAO                                                                                                                                | A traditional organization                                                                                  |
        | ---------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- |
        | Usually flat, and fully democratized                                                                                               | Usually hierarchical                                                                                        |
        | **Voting **required by members for any changes to be implemented                                                                   | Depending on **structure**, changes can be demanded from a **sole party**, or **voting **may be offered     |
        | **Votes tallied**, and **outcome **implemented **automatically **without trusted intermediary                                      | If voting allowed, **votes are tallied internally**, and **outcome **of voting must be **handled **manually |
        | **Services **offered are **handled automatically** in a **decentralized manner** (for example distribution of philanthropic funds) | Requires **human handling, or centrally controlled** automation, prone to manipulation                      |
        | All activity is transparent and fully public                                                                                       | Activity is typically private, and limited to the public                                                    |

        结构，改变投票，计票和结果实施，服务，公示

    *   my ans

        *   DAO is decentralized autonomous organization&#x20;

        *   organzation structure — flat and fully demo — hierarchy

        *

*   Explain what a consensus rule is.

    *   real ans:

        所有参与者都必须就已经发生的所有交易 \* \* 达成共识

        1\)不论(whether or not)参与者是否参与某项交易 \* \*

        2\)所有参与者必须同意一个共同分类账，所有参与者都可以查看所有记录的分类账

        All participants have to **reach consensus over all transactions** that have taken place

        1\)Irrespectively of **whether a participant has taken part** in a particular transaction or not

        2\)All participants have to **agree upon a common ledger** where all participants have **access to all entries ever recorded**



        由于区块链网络可能涉及相互不信任和匿名的当事人，必须采用协商一致的机制，保护分类账免受欺诈或不利的参与者企图双重花费

    *   my ans

        all particia have to reach a consensus over all trans had

        all trans have to agree upon same ledger where all p have access to enries ever recorded&#x20;

*   Compare and Contrast two protocols –PoW, PoS, PoA, etc

    *   real ans:

        PoW:

        Proof of Work (PoW): You need to solve a crypto puzzle by **spending money on dedicated equipment** and **use a lot of electricity** • You **get a reward if you solve the puzzle**

        你需要通过花钱购买专用设备和大量电力来解决密码谜题·如果你解决了谜题，你会得到奖励

        优点：

        does not pay to cheat 作弊是不值得的

        问题：掏钱才能玩（pay-to-play）的模式;非常耗电Very **unenvironmentally** friendly and **consumes** a lot of electricity；通货紧缩deflation ，51% attacks

        PoS proof of stack:

        Miners have to prove they **own a certain amount of currency**, their ‘stake’, to take part (no reward but a transaction fee)The higher stake you have, the more likely you are to generate a block

        矿商必须证明他们拥有一定数量的货币，他们的“股份”，以参与(没有报酬，但交易费)你的赌注越高，你就越有可能生成一个方块

        优点：节能Energy saving;；更加的去中心化more decentralization;避免紧缩avoidance of crunch

        Prevent users from engaging in dishonest behaviour because it will devalue their stake防止用户从事不诚实行为，因为这会使他们的股份贬值

        问题：**the rich get richer problem**

        PoB

        Miners burns some coins by sending the coins a verifiable unspendable address (Eater address)矿工通过向硬币发送一个可验证的不可持久地址（Eater地址）来烧掉一些硬币

        burning the cryptocurrency is showing a **long- term commitment to the coin** by burning as they are taking a short-term loss in exchange for a long-term gain

        烧毁加密货币显示了他们对硬币的长期承诺，因为他们用短期损失换取长期收益

        缺点：

        The resources used to generate the burnt coins is wasted

        用于生产烧焦的硬币的资源被浪费了

        The rich get richer

        不能保证用户永远都能恢复被烧掉的硬币的全部价值

        *   PoA Proof-of-activity:

            Essentially gives or elects a specific number of clients the right to make all of the blocks in the blockchain

            实质上给予或选举特定数量的客户端制作区块链中的所有区块的权利

            Censorship and blacklisting of transactions or certain vendors using their network, may at times, be in the best interest in the majority of the validators (banks)

            审查和黑名单的交易或某些供应商使用他们的网络，有时，可能是最好的利益，在大多数验证(银行)

            优点：效率高，可扩展性强scalability

            问题：验证者可能影响**Validators** are subjected to outside influence from third parties

        Delegated Proof of Stake (DPoS): A reputation system and real-time voting to achieve consensus

        委托利益证明(dpo) : 一个信誉系统和实时投票以达成共识

    *   my ans

        pow proof , miner have to slove a crypto pule by specific equipment and use a lot of electricity

        g: does not pay to chaet

        b; unenvironment firendly , consume electricy ,51 , pay to play, deflation&#x20;

        pos miner have to proof they have a certaion number of currency, as stacke. the more stake they have ....

        g: save , more dece, avoid defloat&#x20;

        b; rich get richer

        pob miner have to burin coins by send the coins to a vertifiable unspendable adress

        g; not pay to chaet

        b： waste, restore all&#x20;

### Platforms

*   Explain gas limit in Ethereum

    *   real ans

        Gas is a unit that measures the amount of computational effort that it will take to execute certain operations&#x20;
        A gas limit
        **The sender of the transaction must specify The maximum amount of gas the sender is willing to pay for the transaction
        The miners will stop executing the moment the gas runs out
        If there is any gas left over, it will be immediately refunded to the operation generator**

        气体是衡量执行某些操作所需的计算工作量的单位。

        气体限制交易的发送方必须具体说明发送方愿意为交易支付的最大气体量。

        一旦天然气用完，矿工将停止执行

        如果有剩余的气体，将立即退还给运营生产商

    *   my ans:



*   what happens when a too much high/low limit is set?

    *   Gas Limit too Low


        If an operation runs out of gas, then it is reverted back to its original state like nothing actually happened


        The operation generator must STILL pay the miners the fee for their computational costs and the operation gets added to the blockchain (even if it has not been executed)

        如果一个操作耗尽了气体，那么它就会恢复到原来的状态，就像什么都没发生一样。

        操作发生器仍然必须支付矿工的计算费用，**操作被添加到区块链中(即使它还没有被执行)**

    *   Gas Limit too High


        Whatever is leftover gets refunded to the sender


        Miners are limited by the block gas limit


        Miners can only include transactions which add up to be less than or equal to the **block gas limit**

        *   气体上限过低

        如果一个操作耗尽了气体，那么它就会恢复到原来的状态，就像什么都没发生一样。操作发生器仍然必须支付矿工的计算费用，操作被添加到区块链中(即使它还没有被执行)

        *   气体上限过高

        不管剩下的多少，矿工都要退还给发送者

        **矿工受到block gas limit，矿工只能包括那些加起来小于或等于瓦斯限制的交易**

        if opeatio runs out of gas , the opeatration will revertedd to oringinal state , which like notiong hapen. BUt operation generator tsill need to pay the fee for compuational cost to miner&#x20;



        whatever the gas is left ,the rest gas have to return to sender. and the minher limited b blom li n&#x20;

*   Explain channels in Fabric

    real

    一种机制，通过该机制，**区块链网络中**的一组节点可以私下通信和交易当对等节点、订购方节点和应用程序加入一个渠道时，它们同意协作，共同**共享和管理**与该渠道相**关联**的**账本**的相同**副本**

    A mechanism by which a set of nodes within a blockchain network can communicate and transact privately When peer nodes, orderer nodes and applications join a channel, they agree to collaborate to collectively share and manage identical copies of the ledger associated with that channel

    my ans:

    a mechanism by which a set of node within blockchain network can communicated and transact privately when peer node , ordernode and application join a channel, they agree to collaborated share and manage identical copies of ledger associated with channel



*   Explain vault in Corda

    &#x20;每个节点都维护一个vault-一个数据库，它tracks**它所知道****并且它认为这些状态与自身相关**的所有当前和历史状态，；

    Vault: a database where it tracks all the current and historic states that it is aware of, and which it considers to be relevant to itself

    我们可以从每个节点的角度将账本视为它所知道的所有当前（即非历史）状态的集合(We can think of the ledger from each node’s point of view as the set of all the current (i.e. non-historic) states that it is aware of)







*   what states and state sequences are

    *   real ans

        an **immutable object **representing a fact known by one or more Corda nodes at a specific point in time

        ，表示**一个或多个**Corda节点在**特定时间**点已知的**事实**的一个不可变对象

        When a state needs to be updated, we create a new version of the state representing the new state of the world, and mark the existing state as historic

        当一个状态需要更新时，我们创建一个代表世界新状态的新版本，并将现有状态标记为具有历史意义的状态

    *   my ans

        an immutable object representing a fact known by one or more corda nodes at specific point in time

        weh a stat ned&#x20;

*   Compare and contrast two cryptocurrency platforms

    |                            | Ethereum   | Hyperledger Fabric            | R3 Corda                   |
    | -------------------------- | ---------- | ----------------------------- | -------------------------- |
    | Public /Private:           | Public     | Private                       | Private                    |
    | Consensus Protocol:        | PoS/PoW    | Pluggable (Noop/pBFT/Custom)  | Pluggable(BFT/RAFT/Custom) |
    | Smart Contracts Supported: | Yes        | Yes                           | Yes                        |
    | Smart Contracts Language:  | Solidity   | Golang/node.js                | java/kotlin                |
    | Cryptocurrency:            | Ether      | (Can be modelled in Chaincode | -                          |
    | Transaction Fee:           | Yes (high) | No                            | No                         |



    ethereum fabric corda

    pr pb pb

    contracts

    fee

    consensus pow pof pluggable&#x20;

    solidity

*   Cryptocurrency platforms can be public or private, how does their use differ?

    *   real:

        Public Blockchains (permissionless):proven安全机制，但所有人都可以看到所有交易

        Private Blockchains (permissioned): 确信敏感信息已realised给选定的合作伙伴

        公共区块链(无许可) : 经过验证的安全机制，但是所有的交易都可以被每个私有区块链(许可)看到: 自信的敏感信息被选择的合作伙伴实现往往更快，因为在一个友好的环境，有限的用户数量实现一致同意算法工作

        Public Blockchains (permissionless):&#x20;

        proven security mechanisms, but all transaction can be seen by everyone&#x20;

        Private Blockchains (permissioned):&#x20;

        确信敏感信息已经传达给选定的合作伙伴

        confident that sensitive information is realised to selected partners&#x20;

        由于共识算法在用户数量有限的友好环境中工作，因此往往速度更快

        Tend to be faster as the consensus algorithm works in a **friendly **environment with a l**imited number of users**

    *





### NFTs

*   What are NFTs?

    *   real

        **NFT：** • Is a unit of data stored on a digital ledger, called a blockchain •

        &#x20;Can be associated with a particular digital or physical asset •&#x20;

        May be associated with a license to use the asset for a specified purpose&#x20;

        • Can be traded and sold on digital markets

        *   是一个存储在数字账本上的数据单位，称为区块链

        *   可以与特定的数字或实物资产相关联 - 可能与为特定目的使用该资产的许可相关联

        *   可以在数字市场上进行交易和销售



    *   my

        *   a unit data stored on ledger , called a blckchain

        *   it can associated with specifc digial or physical assert and it als ca nsa

        *   associated with license to use assert for specifc assset&#x20;



*   what fungible and non-fungible means,** how it is supported by the blockchain**

    *   real&#x20;

        **可替代性：**

        可替换指的是不能与其他事物区分开来的事物，它是可互换的、可替换的或统一的

        Fungible refers to something that cannot be distinguished from another thing, it is interchangeable, substitutable or uniform

        **non-fungible：不可替代：**

        任何不能轻易替换的东西都是不可替换的(独一无二的)•你的旧电吉他、一本签名书或者其他类似的收藏品据说都是不可替换的•即使你收藏的那些不再流通的硬币也是不可替换的•基本上，不可替换只是一个高雅的词汇，用来表示某种独一无二的东西，因此就无法轻易地互换

        Anything that cannot be so easily replaced is non-fungible (unique) • Your old telecaster guitar, an autographed book, or other such collectibles are said to be nonfungible • Even your collection of coins that are no longer in circulation are nonfungible • Basically, nonfungible is just a high-brow word for something that is **unique **and thereby defies easy interchangeability



        **NFT 能够分配或声明任何独特数字数据的所有权，可通过使用以太坊的区块链作为公共分类帐进行跟踪**。

        NFT is stored in blockchain with extra information. such as The ownership of an NFT is recorded in the blockchain, and can be transferred by the owner, allowing NFTs to be sold and traded &#x20;



    *   my

        fungible : sonmething cannot distinguished with oterhing thing and it is interchangeable , unifrom and substituable&#x20;

        cannot so easily replace such n

        nft&#x20;



*   What are issues over NFTs? –explain TWO or THREE of them

    plagiarism and fraud.&#x20;

    **1,Plagiarism and Fraud:剽窃欺诈**

    There have been cases of artists having their work sold by others as an NFT, without permission(曾经发生过艺术家的作品在未经许可的情况下被他人作为NFT出售的情况。)The general ease of creating plagiarized NFTs, along with the anonymity of minting NFTs, has made it harder to pursue legal action against NFT plagiarists(创造抄袭的NFT普遍很容易，再加上铸造NFT的匿名性，使得对NFT抄袭者采取法律行动变得更加困难。)There is currently a lack of market incentive for NFT marketplaces to crack down on plagiarism(目前，市场上缺乏对NFT市场打击抄袭行为的激励措施。)



    plagiarism and fraud some arts was seld without license by it creator. and it is also easy to plagiarize NFT and due to anonymity of miniting NFT , it is hard to&#x20;

    **2Data Hosting and Storage数据托管和存储**

    An NFT and the digital asset it represents are typically stored separately • The NFT is stored on the blockchain and contains information on where the digital asset is located • The NFT is connected to the digital asset via a link • However, if the digital asset is deleted or the server hosting it fails or otherwise goes offline • The link will break and the NFT that remains will be worthless because it would no longer be associated with the digital asset and there is no way to back up the NFT • Since the NFT is unique and cannot be replaced, the NFT purchaser might be left without recourse • Based on the use of the specific NFT, this can result business interruptions, regulatory record keeping violations, and loss of data

    NFT 和它所代表的**数字资产**通常是**分开存储**的•**N**FT存储在区块链上，包含数字资产所在地的信息•NFT**通过一个链接**与数字资产相连•然而，**如果数字资产被删除**，或者服务器出现故障或者脱机•链接将中断，剩下的**NFT将毫无价值**，因为它将不再与数字资产相关联，也没有办法支持NFT•由于NFT是独一无二的，无法替代，NFT的购买者可能会失去追索权•基于特定NFT的使用，这可能导致业务、监管记录违规和数据丢

    **3violate Data Protection Laws违反数据保护法** Some data protection laws give individuals the right to the erasure of their personal data（**一些数据保护法赋予个人删除其个人数据的权利。**他们的个人数据） • But the immutable nature of the blockchain poses an obstacle to the execution of this right（但区块链的**不可改变性对这一权利的执行造成了障碍**。执行这 一权利的障碍） • Data protection laws also sometimes provide individuals with the right to rectify inaccuracies in their personal data, and blockchain technology might make this right functionally impossible to exercise（数据保护法有时也为个人提供 数据保护法有时还规定个人有权**纠正其个人数据**中的不准确之处，而区块链 技术可能使这项权利在功能上无法行使。） • As such, NFTs that contain personal information might violate data protection laws（因此，**包含个人信息的**NFT可能会违反数据保护法）



    **4其他一些法律问题**

    • roperty law –It is important to consider which legal system governs your ability to sell or secure an NFT. The asset's location generally determines property law. However, NFTs represent a unique copy of the asset rather than the underlying asset itself.财产法--重要的是要考虑哪种法律制度制约着你的能力。出售或担保国家信托基金的能力。资产的位置通常决定了财产法。然而，非正规金融工具代表了资产的一个独特副本，而不是基础资产本身。 • Money laundering –The value of NFT transactions and the widespread use of cryptocurrency inevitably raises concerns about whether these transactions are being used to circumvent anti-money laundering regulations.洗钱--NFT交易的价值和加密货币的广泛使用不可避免地引起了人们对这些交易是否被用来规避反洗钱法规的关注。 • Regulatory –Unregulated NFT transactions, including "wash trading", would be banned in traditional investment markets like equities because they give an artificial impression of demand for an asset.监管--不受监管的NFT交易，包括 "清洗交易"，在股票等传统投资市场上会被禁止，因为它们给人以对资产需求的人为印象 • Taxation issues –As with cryptocurrencies, the law has been slow to catch up with NFTs and taxation -with difficulties in determining where NFTs are situated for tax purposes. NFTs fall into something of a tax black hole.

    税收问题--就像加密货币一样，法律对NFT和税收的追赶很慢--在确定NFT的税收所在地方面存在困难。 困难。NFTs陷入了某种程度的税收黑洞。





信任来自于technology and cryptography

between people who may not otherwise trust each other 不信任

secure, trusted records 记录

on a peer-to-peer distributed network 分布 and every note have a whole copy of blockchain

信任来自于technology and cryptography

between people who may not otherwise trust each other 不信任

secure, trusted records 记录

on a peer-to-peer distributed network 分布 and every note have a whole copy of blockchain



secure  privacy  &#x20;



hierarchical   democratized

Data Protection Laws





一种机制，通过该机制，区块链网络中的一组节点可以私下通信和交易当对等节点、订购方节点和应用程序加入一个渠道时，它们同意协作，共同共享和管理与该渠道相关联的账本的相同副本

